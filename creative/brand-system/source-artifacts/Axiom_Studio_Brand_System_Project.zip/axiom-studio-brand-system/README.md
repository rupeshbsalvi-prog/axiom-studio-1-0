# Axiom Studio Brand System

Version: `1.0.0-draft.1`  
Status: Draft for Brand Council approval  
Prepared: 2026-08-01

This package converts the Axiom Studio brand into a versioned, implementation-ready system. It combines strategy, messaging, design tokens, governance, measurement, templates and an optional React reference panel.

## Included

- `config/`: authoritative machine-readable brand data.
- `docs/`: complete roadmap and operating guidance.
- `src/brand/core/`: dependency-free TypeScript types and validation.
- `src/brand/react/`: optional React provider and hook.
- `src/brand/styles/`: CSS variables.
- `src/brand/components/`: optional internal roadmap panel.
- `roadmap/`: standalone interactive HTML and Mermaid source.
- `templates/`: reusable briefs, audits and QA.
- `integration/`: controlled project-injection guidance.

## Boundary

Static configuration and presentation code only. No secrets, external runtime modules, arbitrary endpoints, provider dispatch or dynamic code execution.

## Validate

```bash
node scripts/validate-brand.mjs
```

The package is structured for Axiom Studio's React + TypeScript + Vite baseline. Exact repository paths must be reconciled before merge.
