# Suggested File Mapping

| Package path | Typical Axiom destination | Required |
|---|---|---|
| `config/*.json` | `docs/brand/config/` or `src/brand/data/` | Yes |
| `src/brand/core/*` | `src/brand/core/` | Yes |
| `src/brand/styles/axiom-brand-tokens.css` | design-system/global styles | Yes |
| `src/brand/react/*` | `src/brand/react/` | Optional |
| `src/brand/components/*` | internal documentation route | Optional |
| `docs/*` | project documentation | Yes |
| `templates/*` | brand operations workspace | Recommended |
| `roadmap/*` | static internal portal | Optional |
